import React,{useState,useEffect} from 'react'
import {useParams,Link} from 'react-router-dom';
import ProductService from '../service/ProductService';
export default function ProductView() {
    const params=useParams()
    var [product,setproduct]=useState({pid:"",pname:"",qty:"",price:""})
    useEffect(()=>{
         ProductService.getById(params.id)
         .then((result)=>{
            console.log(result.data)
            setproduct({...result.data});
         })
    },[])
  return (
    <div>
       <div className="card" >
           <div className="card-body">
                  <h5 className="card-title">{product.pname}</h5>
    <h6 className="card-subtitle mb-2 text-muted">{product.pid}</h6>
    <p className="card-text">{product.qty} ----- {product.price}</p>
    <Link to="/table">
        <button type="button" name="back" id="back">Back</button>
    </Link>
  </div>
</div> 
    </div>
  )
}
