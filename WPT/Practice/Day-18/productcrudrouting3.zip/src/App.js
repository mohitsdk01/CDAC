import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css"
import {Routes,Route} from 'react-router-dom'
import Header from './components/Header';
import Footer from './components/Footer';
import MainNavBar from './components/MainNavBar';
import ProductTable from './pages/ProductTable';
import HomeComponent from './pages/HomeComponent';
import ProductList from './pages/ProductList';
import ProductForm from './pages/ProductForm';
import ProductEdit from './pages/ProductEdit';
import ProductView from './pages/ProductView';
function App() {
  return (
    <div>
    <Header></Header>
    <MainNavBar></MainNavBar>
    <Routes>
      <Route path="/" element={<HomeComponent></HomeComponent>}></Route>
      <Route path="/table" element={<ProductTable></ProductTable>}></Route>
      <Route path="/list" element={<ProductList></ProductList>}></Route>
      <Route path="/form" element={<ProductForm></ProductForm>}></Route>
      <Route path="/edit/:id" element={<ProductEdit></ProductEdit>}></Route>
      <Route path="/view/:id" element={<ProductView></ProductView>}></Route>
    </Routes>
    <Footer></Footer>
    </div>
  );
}

export default App;
