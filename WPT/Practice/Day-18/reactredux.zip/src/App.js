import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
import DisplayData from './components/DisplayData';
import {useDispatch} from 'react-redux'
import { new_booking,cancel_booking } from './redux/action/bookingaction';
function App() {
  let [formdetails,setformdetails]=useState({id:"",name:"",amt:""})
  const dispatch=useDispatch()
const bookticket=()=>{
  let action=new_booking(formdetails.id,formdetails.name,formdetails.amt)
  dispatch(action);
  //clear the form
  setformdetails({id:"",name:"",amt:""})
}
const cancelticket=()=>{
  //generate the action object
  let action=cancel_booking(formdetails.id,formdetails.name,formdetails.amt)
   // dispatches the action to store
  dispatch(action);
  //clear the form
  setformdetails({id:"",name:"",amt:""})
}
const changeid=(event)=>{
  setformdetails({...formdetails,id:event.target.value})

}
const changename=(event)=>{
  setformdetails({...formdetails,name:event.target.value})

}
const changeamt=(event)=>{
  setformdetails({...formdetails,amt:event.target.value})

}


  return (
   <div>
   <DisplayData></DisplayData>
   <hr size="4px" color="red"></hr>
    <form>
        Id : <input type="text" name="id" id="id"
        value={formdetails.id}
        onChange={changeid}></input><br></br>
        Name : <input type="text" name="name" id="nm"
        value={formdetails.name}
        onChange={changename}></input><br></br>
        Amount : <input type="text" name="amt" id="amt"
        value={formdetails.amt}
        onChange={changeamt}></input><br></br>
        <button type="button" name="btn" id="btn" onClick={bookticket}>Book ticket</button>&nbsp;&nbsp;&nbsp;
        <button type="button" name="btn1" id="btn1" onClick={cancelticket}>Cancelk ticket</button>
    </form>
   </div>
  );
}

export default App;
