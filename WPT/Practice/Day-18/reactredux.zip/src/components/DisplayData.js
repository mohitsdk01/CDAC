import React from 'react'
import {useSelector} from 'react-redux'
export default function DisplayData() {
    let reservationlist=useSelector((state)=>state.resevationlist)
    let cancellationList=useSelector((state)=>state.cacellationlist)
    let amount=useSelector((state)=>state.amount)
  return (
    <div>
        <h1>Reservation List</h1>
        <table border='2'><thead><tr><th>Id</th><th>Name</th><th>Amount</th></tr></thead>
        <tbody>
        {reservationlist.map(ob=><tr key={ob.id}>
             <td>{ob.id}</td>
             <td>{ob.name}</td>
             <td>{ob.amt}</td>
        </tr>)}
        </tbody>
        </table>
        <h1>cancellation List</h1>
        <table border='2'>
        <thead>
            <tr><th>Id</th><th>Name</th><th>Amount</th></tr>
            </thead>
            <tbody>
            {cancellationList.map(ob=><tr key={ob.id}>
                <td>{ob.id}</td>
                <td>{ob.name}</td>
                <td>{ob.amt}</td>
            </tr>)}
            </tbody>
        </table>
        <h3>Total Amount : {amount}</h3>
    </div>
  )
}
