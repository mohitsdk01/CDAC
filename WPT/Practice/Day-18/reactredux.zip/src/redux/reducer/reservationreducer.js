export const manageReservationList=(oldreservationlist=[],action)=>{
    console.log("in manage reservation list")
   switch(action.type){
    case "new_booking":
        return [...oldreservationlist,{...action.payload}]
        
    case "cancel_booking":
        return oldreservationlist.filter(ob=>ob.id!=action.payload.id)
    default:
        return oldreservationlist;
   }


}

export const manageCancellationList=(oldcancellationlist=[],action)=>{
    console.log("in manage cancellation")
    switch(action.type){
    case "cancel_booking":
         return [...oldcancellationlist,{...action.payload}]
     default:
         return oldcancellationlist;
    }
 
    
 }


 export const manageAmount=(oldamt=5000,action)=>{
    console.log("in manage amount")
    switch(action.type){
     case "new_booking":
         return oldamt+parseInt(action.payload.amt)
         
     case "cancel_booking":
         return oldamt-parseInt(action.payload.amt)
     default:
         return oldamt;
    }
 
    
 }