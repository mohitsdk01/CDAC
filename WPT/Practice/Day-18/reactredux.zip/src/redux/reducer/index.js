import {combineReducers} from 'redux';
import { manageReservationList,manageCancellationList,manageAmount } from './reservationreducer';

const railwaystore=combineReducers({
    amount:manageAmount,
    resevationlist:manageReservationList,
    cacellationlist:manageCancellationList
})

export default railwaystore;