//write action createtor function
//function to create new_booking action
export const new_booking=(id,name,amt)=>{
    return {
        type:"new_booking",
        payload:{id:id,name:name,amt:amt}
    }
}

//function to create new_booking action
export const cancel_booking=(id,name,amt)=>{
    return {
        type:"cancel_booking",
        payload:{id:id,name:name,amt:amt}
    }
}